#' runLinclust
#'
#' Cluster proteins from a set of organisms
#'
#' @references Steinegger and Söding \emph{Clustering huge protein sequence sets in linear time:} \url{https://doi.org/10.1038/s41467-018-04964-5}
#'
#' @param accessionList character vector containing GenBank accession numbers
#'
#' @details This function groups all proteins from all organisms in the accessionList using an R and C++ implementation of the Linclust method of Steinegger and Söding. Minor differences in protein groupings from the Steinegger and Söding implementation and the RBiotools implementation may be observed. Among other differences, Steinegger and Söding's code employs an SIMD Smith-Waterman C++ library for local, gapped protein alignments, while RBiotools uses the \code{pairwiseAlignment} function from the R \code{Biostrings} package.
#'
#' @return homologyMatrix.df, a data frame with a column for each organism and a row for each protein group, with data frame elements containing counts of proteins for each organism / protein group combination.
#'
#' @examples
#' \dontrun{
#' accessionIDs <- c(
#'   "AP012306",  # Escherichia coli str. K-12 substr. MDS42 DNA
#'   "KK583188",  # Escherichia coli DSM 30083 = JCM 1649 = ATCC 11775
#'   "U00096",    # Escherichia coli str. K-12 substr. MG1655
#'   "CP000802",  # Escherichia coli HS
#'   "CP000800",  # Escherichia coli E24377A
#'   "AP009378",  # Escherichia coli SE15
#'   "FM180568",  # Escherichia coli 0127:H6 E2348/69
#'   "CU928163",  # Escherichia coli UMN026
#'   "CP008957",  # Escherichia coli O157:H7 str. EDL933
#'   "CP027027",  # Shigella dysenteriae strain E670/74
#'   "CP026802",  # Shigella sonnei strain ATCC 29930
#'   "CP026877",  # Shigella boydii strain ATCC 35964
#'   "CP026793",  # Shigella flexneri strain 74-1170
#'   "CP015831"   # Escherichia coli O157 strain 644-PT8
#' )
#'
#' runLinclust(accessionIDs)
#' }
#'
#' @useDynLib RBiotools
#' @exportPattern "^[[:alpha:]]+"
#'
#' @importFrom Biostrings nchar pairwiseAlignment pid
#' @importFrom stringr str_count str_remove



runLinclust <- function(accessionList, mode = "SLOW", verbose = FALSE) {

  ## Arguments:
  ##   accessionList - a list of GenBank identifiers for which Prodical has called genes
  ##
  ##   mode - 
  ##     FAST - the "pre_clust" dataset from Linclust, which is created with
  ##            Hamming ungapped alignment, will be used for protein groupings
  ##     SLOW - the "pref_rescore2" dataset from Linclust will be used for
  ##            Smith-Waterman gapped alignment by Biosequences::pairwiseAlignment
  ##            to compute the "clust" dataset, which will then be merged
  ##            with the "pre_clust" dataset for gene groupings in "final_clust"
  ##      Note: Smith_Waterman gapped alignment is more expensive than Hamming ungapped 
  ##            alignment, but for most sets of organisms, there many more Hamming
  ##            alignments than Smith-Waterman alignments, so the cost of SLOW mode is
  ##            generally not much greater than the cost of FAST mode. Therefore, the
  ##            default mode is SLOW, and the mode parameter is not currently documented.
  ##
  ##   verbose - controls whether processing information will be provided to the user

  ## TEMP COUNTER ###
  gappedAlignmentCount <- 0

  ## Global variables

  # Check whether RBiotools has been initialized,
  #   that is, do the global variables exist?

  if (!exists("GenomeSeqList")) {   # NOT initialized
    initializeRBiotools()
  }

  get("ProdigalCalls", envir = .GlobalEnv)


  Sequences.df <- data.frame(identifier=character(), 
                             protein=character(), 
                             stringsAsFactors=FALSE) 

  incr <- 32   # increment for interleaving, value from the C++ Linclust implementation

  # Replace the accessionList with a list of identifiers that have been checked
  #   See the checkIdentifier function documentation

  checkedList <- character()
  for (uncheckedID in accessionList) {
    checkedID <- checkIdentifier(uncheckedID)
    if ( !(checkedID %in% checkedList) ) {
      checkedList <- c(checkedList, checkedID)
    }
    else {
      cat(paste(checkedID, " already seen in accession list ... ignored\n"))
    }
  }

  # Check for genomes in accession list not downloaded

  for (aaa in checkedList) {
    seqSet <- GenomeSeqList[aaa][[aaa]]
    if (is.null(seqSet)) {  # NOT downloaded
      downloadGenBank(aaa)
    }
  }

  # Check for genomes in accession list for which protein genes have not be called

  for (aaa in checkedList) {
    nextOrganism.df <- ProdigalCalls[which(ProdigalCalls$accession == aaa),]
    if (nrow(nextOrganism.df) == 0) {  # NOT called
      cat(paste("Calling protein genes for accession ID:", aaa, "\n"))
      runProdigal(aaa, verbose = FALSE)
    }
  }

  for (aaa in checkedList) {

    if (verbose) {
      cat(paste0("Processing ", aaa, "\n"))
    }

    nextOrganism.df <- ProdigalCalls[which(ProdigalCalls$accession == aaa),]

    nextAccession.df  <- nextOrganism.df$accession
    nextIdentifier.df <- nextOrganism.df$identifier
    nextProtein.df    <- nextOrganism.df$protein
    nextEntry.df      <- cbind(nextAccession.df, nextIdentifier.df, nextProtein.df)
    Sequences.df      <- rbind(Sequences.df, nextEntry.df)
  }
  
  # Rename columns
  colnames(Sequences.df) <- c("accession", "identifier", "protein")


  # Interleave the protein sequences, consistent with C++ implementation of Linclust
  # --------------------------------------------------------------------------------
  
  last <- nrow(Sequences.df)
  newOrder.df <- data.frame(accession=character(),
                            identifier=character(),
                            protein=character(), 
                            stringsAsFactors=FALSE)
  n <- 1
  beg <- 0
  for (i in 1:incr) {
    beg <- beg + 1
    j <- beg
    while (j <= last) {
      newOrder.df <- rbind(newOrder.df, Sequences.df[j,])
      n <- n + 1
      j <- j + incr
    }
  }

  # Remove "*" from the end of protein sequences
  # --------------------------------------------

  for (i in 1:last) {
    newOrder.df[i,]$protein <- str_remove(newOrder.df[i,]$protein, '\\*$')
  }

  # Call the Rcpp function computeLinclustDatasets to create the datasets, in order,
  #  * pref (later reused by Linclust as "pref_filter1")
  #  * pref_rescore1
  #  * pre_clust
  #  * order_redundancy
  #  * pref_filter2
  #  * pref_rescore2
  # and return pre_clust ...
  # ... and pref_rescore2, if SLOW mode


  if (mode == "FAST") { dataset_vectors <- as.list(computeLinclustDatasets(newOrder.df,10,0)) }
  if (mode == "SLOW") { dataset_vectors <- as.list(computeLinclustDatasets(newOrder.df,10,1)) }

  # extract pre_clust
  # -----------------

  seqId  <- dataset_vectors[["preClust_seqId"]]
  repseq <- dataset_vectors[["preClust_repseq"]]

  # Adjust seqId for 1-based indexing .... v
  pre_clust.df <- data.frame(seqId = seqId+1, repseq = repseq, stringsAsFactors = FALSE)
  pre_clust.df$seqId  <- as.integer(pre_clust.df$seqId)
  pre_clust.df$repseq <- as.logical(pre_clust.df$repseq)

  # Add group number to pre_clust.df
  # --------------------------------

  groupNum <- c()
  gNum <- 0

  for (i in 1:nrow(pre_clust.df)) {
    if (pre_clust.df[i,]$repseq == TRUE) {
      gNum = gNum + 1
    }
    groupNum <- c(groupNum, gNum)
  }

  pre_clust.df <- cbind(pre_clust.df, groupNum)

  # DEBUG early return
  # return(pre_clust.df)




  if (mode == "FAST") {
    # Use pre_clust.df to create a homology matrix
    homology_clust.df <- pre_clust.df
  }

  else if (mode == "SLOW") {

    # extract pref_rescore2
    # -----------------------

    seqId     <- dataset_vectors[["pref_rescore2_seqId"]]
    prefScore <- dataset_vectors[["pref_rescore2_prefScore"]]
    diagonal  <- dataset_vectors[["pref_rescore2_diagonal"]]

    groupSize <- dataset_vectors[["pref_rescore2_groupSize"]]


    # Adjust seqId for 1-based indexing ........ v
    pref_rescore2.df <- data.frame(seqId = seqId+1, prefScore = prefScore, diagonal = diagonal, stringsAsFactors = FALSE)
    pref_rescore2.df$seqId     <- as.integer(pref_rescore2.df$seqId)
    pref_rescore2.df$prefScore <- as.integer(pref_rescore2.df$prefScore)
    pref_rescore2.df$diagonal  <- as.integer(pref_rescore2.df$diagonal)
  
    # DEBUG early return
    # return(pref_rescore2.df)

    # Add additional information to the newOrder dataframe ...
    # --------------------------------------------------------
    # DEBUG early return
    # return(newOrder.df)

    # 1) seqId from the Rcpp function are 0-indexed
    #    switch to 1-indexed ....v
    newOrder.df <- cbind(seq.int(1,nrow(newOrder.df),1), newOrder.df)

    # 2) protein length (# of AAs)
    newOrder.df <- cbind(newOrder.df, nchar(newOrder.df$protein))

    # Rename columns
    colnames(newOrder.df) <- c("seqId", "accession", "identifier", "protein", "length")

    # DEBUG early return
    # return(newOrder.df)

    # Process the pref_rescore2 dataset to create the "aln" alignment dataset
    # -----------------------------------------------------------------------

    # cat('Process the pref_rescore2 dataset to create the "aln" alignment dataset\n')

    lambda <-  0.3207378152604
    logK   <- -1.9729463569813

    seqIdThreshold <- 0.9         # 90% sequence identity across the alignment required
                                  # 89% sequence identity across the alignment required ... returns significantly more
    coverageThreshold <- 0.8      # 80% of each sequence must be covered by the alignment


    # fill a data frame with group information contained in clust

    aln.df <- data.frame(group=integer(),
                         seqId=integer(),
                         stringsAsFactors=FALSE)

    numEntries <- nrow(pref_rescore2.df)
##  cat(paste0("pref_rescore2.df entries: ", numEntries, "\n"))

if (numEntries > 0) {

    groupNum <- 1
    i <- 1

    while (i <= numEntries) {

      # Process first sequence in group - "rep" ("representative")
      rep <- pref_rescore2.df[i,]$seqId

      newGroup.df <- data.frame(group=integer(),
                                seqId=integer(),
                                stringsAsFactors=FALSE)

      row <- c(groupNum, rep)
      newGroup.df <- rbind(newGroup.df, row)

      i <- i + 1

      gSiz <- groupSize[rep]
      if (gSiz > 1) {
        for (j in 2:gSiz) {
          mem <- pref_rescore2.df[i,]$seqId
          # Call SW alignment to align mem with rep
          pattern <- newOrder.df[rep,]$protein
          subject <- newOrder.df[mem,]$protein
          a <- pairwiseAlignment(pattern, subject, type = "local", substitutionMatrix = "BLOSUM62", gapOpening = 11, gapExtension = 1)

          ## Smith-Waterman alignment counter ###
          gappedAlignmentCount <- gappedAlignmentCount + 1

          adjustedScore <- as.integer(((lambda * a@score - logK)/log(2.0)) + 0.5)

          # cat(paste0("rep: ", rep, " org: ", newOrder.df[rep,]$accession, " seq: ", newOrder.df[rep,]$identifier, "\n"))
          # cat(paste0("mem: ", mem, " org: ", newOrder.df[mem,]$accession, " seq: ", newOrder.df[mem,]$identifier, "\n"))
          # cat(paste0("rep: ", a@pattern, "\n"))
          # cat(paste0("mem: ", a@subject, "\n"))
          # cat(paste0("score: ", a@score, "\n"))
          # cat(paste0("adjustedScore: ", adjustedScore, "\n"))

          # check whether a member can be added to the alignment
          # ----------------------------------------------------

          addMember <- TRUE

          # compute sequence identity across the alignment
          seqId <- pid(a) / 100.0     # as a percentage

          # cat(paste0("seqId: ", seqId, "\n"))


          # Linclust default for computing sequence identity is --cov-mode 0
          #   which results in alignment mode SCORE_COV (see Matcher.cpp).
          # To compute sequence identity for alignment mode SCORE_COV,
          #   the C++ function "estimateSeqIdByScorePerCol" is called
          #   and makes the following computation using the alignment score:

          # This statement:
          # estimatedSeqId <- (a@score / max(nchar(a@pattern),nchar(a@subject))) * 0.1656 + 0.1141
          # ... doesn't really make sense because because the pattern and the subject are the same length

          # Therefore, don't count gaps:

#         In RBiotools versions prior to version 0.5.5
#         --------------------------------------------
#         patternLen <- Biostrings::nchar(a@pattern) - str_count(a@pattern, "-")
#         subjectLen <- Biostrings::nchar(a@subject) - str_count(a@subject, "-")

#         Modified in version 0.5.5 to fix error due to Biostrings::nchar no longer working with XStrings
#         -----------------------------------------------------------------------------------------------
          patternLen <- Biostrings::nchar(as.character(a@pattern)) - str_count(as.character(a@pattern), "-")
          subjectLen <- Biostrings::nchar(as.character(a@subject)) - str_count(as.character(a@subject), "-")

          estimatedSeqId <- (a@score / max(patternLen, subjectLen)) * 0.1656 + 0.1141

          # cat(paste0("estimatedSeqId: ", estimatedSeqId, "\n"))

          if (estimatedSeqId < seqIdThreshold) {
            addMember <- FALSE
            # cat(paste0("  eXcluded\n"))
          }

          if (addMember) {
            # compute sequence coverage by the alignment
            patternCoverage <- patternLen / nchar(pattern)
            subjectCoverage <- subjectLen / nchar(subject)

            # cat(paste0("patternCoverage: ", patternCoverage, "\n"))
            # cat(paste0("subjectCoverage: ", subjectCoverage, "\n"))

            if ((patternCoverage < coverageThreshold) || (subjectCoverage < coverageThreshold)) {
              addMember <- FALSE
              # cat(paste0("  eXcluded\n"))
            }
          }

          if (addMember) {
            # cat(paste0("  adding member\n"))
            row <- c(groupNum, mem)
            newGroup.df <- rbind(newGroup.df, row)
          }
          i <- i + 1
        }

        if (nrow(newGroup.df) > 1) {
          colnames(newGroup.df) <- c("group", "seqId")    # make sure column names match
          aln.df <- rbind(aln.df, newGroup.df)
          groupNum <- groupNum + 1
        }
      }

    }

    cat(paste0("Number of Smith-Waterman alignments: ", gappedAlignmentCount, "\n"))


    # DEBUG early return
    # return(aln.df)


    # Process the "aln" dataset to create the "clust" dataset
    # -------------------------------------------------------

    # Copy "aln" into "clust"
    clust.df <- aln.df

    # Merge groups within "clust"
    # ---------------------------

    # Find sequence IDs in clust that occur multiple times

    seqId_occur <- data.frame(table(clust.df$seqId))
    seqId_occur <- seqId_occur[order(-seqId_occur$Freq),]

    # Make a list (integer vector) of seqId's with multiple occurrences
    seqId_dups <- data.frame(seqId_occur[which(seqId_occur$Freq > 1),], stringsAsFactors = FALSE)
    dupList <- as.integer(as.vector(seqId_dups[,"Var1"]))

    # Iterate over the sequence IDs with multiple occurrences
    for (i in dupList) {
      # Find seqId's groups
      gList <- data.frame(clust.df[which(clust.df$seqId == i),], stringsAsFactors = FALSE)
      groups <- as.integer(as.vector(gList[,"group"]))
  
      if (length(groups) > 1) {  # check, because groups are being updated
        minGroup <- min(groups)  # use the minimum group number for all of seqId's groups
        for (j in groups) {
          clust.df$group[clust.df$group == j] <- minGroup
        }
      }
    }

    # Remove duplicate sequence IDs
    clust.df <- clust.df[!duplicated(clust.df$seqId),]

    # Order clust
    clust.df <- clust.df[order(clust.df$group, clust.df$seqId),]

    # DEBUG early return
    # return(clust.df)



    # Merge groups in pre_clust with group information from clust
    # -----------------------------------------------------------

    final_clust.df <- pre_clust.df    # pre_clust.df will be updated to become the final clustering

    # Create map of seqId to position in final_clust

    seqMap <- integer(nrow(final_clust.df))    # A vector of zeros

    for (i in 1:nrow(final_clust.df)) {
      seqMap[final_clust.df[i,]$seqId] = i
    }

    # Iterate through clust
    # ---------------------

    # cat(paste0("Trace of iteration through clust\n"))

    entries <- nrow(clust.df)
    i <- 1
    while (i <= entries) {

      # cat(paste0("i: ", i, "\n"))

      # Make a list of all group members
      groupNum <- clust.df[i,]$group
      members <- c(clust.df[i,]$seqId)
      i <- i + 1
      while((clust.df[i,]$group == groupNum) && (i <= entries)) {
        members <- c(members, clust.df[i,]$seqId)
        i <- i + 1
      }

      # cat(paste0("  group members in clust: ", members, "\n"))
  
      # Iterate over the group members in final_clust ...
      # ... to find all groups they are in
  
      groupList <- c()
      for (j in members) {
        group <- final_clust.df[seqMap[j],]$groupNum
        groupList <- c(groupList, group)
      }
      sortedGrp <- sort(groupList)

      # cat(paste0("  groups in final_clust: ", sortedGrp, "\n"))
  
      sortedGrp <- sortedGrp[!duplicated(sortedGrp)]
      minGroup <- min(sortedGrp)   # use the smallest group number ...

      # cat(paste0("  smallest group number: ", minGroup, "\n"))
  
      # ... and merge all the groups to which these sequences belong
      #     into a single group
  
      for (j in sortedGrp) {

        # cat(paste0("    group number: ", j, "\n"))
        # cat(paste0("      final_clust entries: ", which(final_clust.df$groupNum == j), "\n"))
        
        final_clust.df[which(final_clust.df$groupNum == j),]$groupNum <- minGroup
      }
    }

}
    else {
      final_clust.df <- pre_clust.df    # final_clust.df IS pre_clust.df because pref_rescore2.df is empty
    }

    # DO NOT reorder ... final_clust is ALREADY ordered by group number, with the "representive" sequence first
    # final_clust.df <- final_clust.df[order(final_clust.df$groupNum, final_clust.df$seqId),]  # Order by group number

    # DEBUG early return
    # return(final_clust.df)

    # Use final_clust.df to create a homology matrix
    homology_clust.df <- final_clust.df
     
  }

  else {
      cat(paste('"', mode, '"', " is not a recognized mode\n"))
      return()
  }

  # Compute a homology matrix
  # -------------------------


  # Reorder the cluster file by group number, then by sequence ID
  homology_clust.df <- homology_clust.df[order(homology_clust.df$groupNum, homology_clust.df$seqId),]

  homologyTrace <- FALSE
  if (homologyTrace) cat("Computing a homology matrix\n")

  homologyMatrix.df <- data.frame(matrix(ncol = length(checkedList), nrow = 0))

  numEntries <- nrow(homology_clust.df)
  if (homologyTrace) { cat(paste0("numEntries: ", numEntries, "\n")) }


  # Iterate through the homology_clust dataframe
  
  i            <- 1
  currentGroup <- 1
  counts       <- integer(length(checkedList))  ## vector of 0's

  if (homologyTrace) { cat(paste0("Group ", currentGroup, ":\n")) }

  while (i <= numEntries) {
    if (homology_clust.df[i,]$groupNum == currentGroup) {
      seq <- homology_clust.df[i,]$seqId                               ## Sequence
      pos <- match(newOrder.df[seq,]$accession, checkedList)           ## Sequence organism (position in accession list)
      if (homologyTrace) { cat(paste0("seq: ", seq, "  pos: ", pos, "\n")) }
      counts[pos] = counts[pos] + 1
      i <- i + 1
    }
    else {
      if (homologyTrace) { cat(paste0("  counts: ", counts, "\n")) }
      homologyMatrix.df <- rbind(homologyMatrix.df, counts)            ## Add group counts to homology matrix
      currentGroup <- currentGroup + 1
      if (homologyTrace) { cat(paste0("Group ", currentGroup, ":\n")) }
      counts       <- integer(length(checkedList))                     ## vector of 0's
    }
  }

  if (homologyTrace) { cat(" ... final:\n") }
  if (homologyTrace) { cat(paste0("  counts: ", counts, "\n")) }
  homologyMatrix.df <- rbind(homologyMatrix.df, counts)            ## Add group counts to homology matrix
      
  colnames(homologyMatrix.df) <- checkedList

  return(homologyMatrix.df)

}
