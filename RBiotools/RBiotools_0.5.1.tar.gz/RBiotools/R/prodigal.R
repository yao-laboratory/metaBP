#' prodigal
#'
#' An R implementation of the widely-used protein-coding gene prediction software tool for bacterial and archaeal genomes. The acronym stands for PROkaryotic DYnamic Programming Genefinding ALgorithm.
#'
#' @references Hyall et al. \emph{Prodigal: prokaryotic gene recognition and translation initiation site identification:} \url{https://doi.org/10.1186/1471-2105-11-119}
#'
#' @param genomeSequence DNAString, DNAStringSet, or character name of a FASTA file containing a genomic sequence
#' @param verbose        logical, indicating whether to report algorithm progress consistent with the original C implementation
#'
#' @details Prodigal is a gene-finding program for microbial for genome annotation of either draft or finished microbial sequence. It was developed to predict translation initiation sites more accurately. It was designed to minimize the number of false positive predictions. This implementation exists entirely in the R layer, with code written in R and C, integrated using the \code{Rcpp} package.
#'
#' \emph{\strong{Note:} \code{prodigal} will seldom, if ever, need to be called directly by the \code{RBiotools} user. \code{RBiotools} functions will automatically call \code{prodigal} when necessary.}
#'
#' @return allGenes.df -- a data frame with called genes, genomic coordinates, scores, and nucleotide and protein product sequences
#'
#' @examples
#' \dontrun{
#' organism <- "U00096" # Escherichia coli str. K-12 substr. MG1655
#'
#' # fetch sequence from list of genomic sequences
#' genomeSeq <- GenomeSeqList[organism][[organism]]
#'
#' # Call prodigal with a DNAStringSet ...
#' geneCalls <- prodigal(genomeSeq)
#'
#' # ... or use the name of a FASTA file in the working directory
#' geneCalls <- prodigal("U00096.fasta")
#' }
#'
#' @useDynLib RBiotools
#' @exportPattern "^[[:alpha:]]+"
#'
#' @importFrom Biostrings DNAString DNAStringSet letterFrequency  letterFrequencyInSlidingView matchPattern readDNAStringSet reverseComplement start translate xscat
#' @importFrom Rcpp evalCpp
#' @importFrom stringr str_replace_all
#' @importFrom utils flush.console


prodigal<-function(genomeSequence, verbose = FALSE) {

  DEBUG <- FALSE

  # Auxillary function for prodigal
  calc_most_gc_frame <- function(sequence) {

    # From Prodigal sequence.c: "Creates a GC frame plot for a given sequence.
    #   This is simply a string with the highest GC content frame for a window
    #   centered on position for every position in the sequence."

    WINDOW <- 120   # Size of window for determining GC content - needs to be a factor of 6
                    # The actual window size is one base smaller.

    # Strings to pad the beginning and end of the sequence with non-GC bases
    beg <- DNAString(paste(replicate(WINDOW/6-1, "N"), collapse = ""))
    end <- DNAString(paste(replicate(WINDOW/6-1, "N"), collapse = ""))

    frame1 <- xscat(beg, sequence[seq(1, length(sequence), 3)], end)
    frame2 <- xscat(beg, sequence[seq(2, length(sequence), 3)], end)
    frame3 <- xscat(beg, sequence[seq(3, length(sequence), 3)], end)

    gc1 <- rowSums(letterFrequencyInSlidingView(frame1, WINDOW/3-1, c("G","C")));
    gc2 <- rowSums(letterFrequencyInSlidingView(frame2, WINDOW/3-1, c("G","C")));
    gc3 <- rowSums(letterFrequencyInSlidingView(frame3, WINDOW/3-1, c("G","C")));

    # gc1 will have the greatest length; gc2 and gc3 will be no more than one element shorter
    len1 <- length(gc1)
    len2 <- length(gc2)
    len3 <- length(gc3)

    if ( len2 < len1 ) { gc2 <- c(gc2, -1) }
    if ( len3 < len1 ) { gc3 <- c(gc3, -1) }


    # Create a data frame for the three DNA frames
    all_frames <- data.frame(gc1, gc2, gc3)

    # For each position in the sequence, determine the frame with the highest GC content within the window
    gc_frame <- max_gc_frame(all_frames)

    # Do garbage collection
    # gc(verbose = TRUE)

    return (gc_frame)
  }

  # Main prodigal function

  if (verbose) {
    cat ("Request: Single Genome, Phase: Training\n")
  }

  # The code in this function (up to Point A) differs significantly from the original C implementation,
  #   which uses a bit-string to encode the genomic sequence.

  # We do NOT want string in dataframes to be factors

  options(stringsAsFactors = FALSE)

  # Check the class of the genomeSequence
  # It must be a DNAString, a DNAStringSet, or a character, which is assumed to be the name of a FASTA file

  if (class(genomeSequence) == "DNAString") {
    Sequences <- DNAStringSet(genomeSequence)   # A single DNAString becomes a DNAStringSet of length 1
  }

  else if (class(genomeSequence) == "DNAStringSet") {
    Sequences <- genomeSequence
  }

  else if (class(genomeSequence) == "character") {
    Sequences <- readDNAStringSet(genomeSequence, format = 'fasta')
  }

  else {
    stop ("prodigal genomeSequence must be either a DNAString, a DNAStringSet, or the name of a FASTA file\n")
  }

  if (verbose) {
    cat ("Reading in the sequence(s) to train ... ")
    flush.console()
  }

  # Addition in RBiotools version 0.4.4 and higher
  #   Reduce the length of N-Strings without changing the reading frame
  #
  numSeq <- length(Sequences)
  for (seqNum in 1:numSeq) {
    Sequences[[seqNum]] <- DNAString(str_replace_all(Sequences[[seqNum]], "NNNNNN", ""))
  }
  #
  # End of addition

  sequence <- as.character(Sequences[[1]])

  # If we encounter multiple sequences, we insert TTAATTAATTAA between each one to force stops in all six frames ...

  numSeq <- length(Sequences)

  if (numSeq > 1) {

    spacer <- "TTAATTAATTAA"

    for (seqNum in 2:numSeq) {
      sequence <- paste0(sequence, spacer)
      sequence <- paste0(sequence, as.character(Sequences[[seqNum]]))
    }

    # ... AND we insert TTAATTAATTAA after the final sequence to be consistent with the Prodigal C implementation
    sequence <- paste0(sequence, spacer)

  }

  sequence <- DNAString(sequence)
  reverse <- reverseComplement(sequence)

  seq_len = length(sequence)

  if (verbose) {
    cat (seq_len, "bp sequence created, ")
    flush.console()
  }


  # Set up the TRAINING structure as an R list

  training <- list(
    gc          = numeric(1),
    trans_table = integer(1),
    st_wt       = numeric(1),
    bias        = numeric(3),
    type_wt     = numeric(3),
    uses_sd     = integer(1),
    rbs_wt      = numeric(28),
    ups_comp    = matrix(NA,32,4),
    mot_wt      = array(NA,dim=c(4,4,4096)),
    no_mot      = numeric(1),
    gene_dc     = numeric(4096)
  )

  # From the Prodigal C implementation:
  #   Set the start score weight.  Changing this number can dramatically affect the performance of the program.
  #   Some genomes want it high (6+), and some prefer it low (2.5-3).  Attempts were made to determine this weight
  #   dynamically, but none were successful.  Therefore, we just manually set the weight to an average value that
  #   seems to work decently for 99% of genomes.  This problem may be revisited in future versions.

  training$st_wt = 4.35;

  # This initial implementation of R Prodigal assumes that we are working with the finished genome sequence
  # of a microbe that uses the Bacterial, Archaeal, and Plant Plastid Code, translation table 11.

  training$trans_table = 11;

  # Compute GC content

  training$gc <- as.double(letterFrequency(sequence,"GC") / seq_len)

  if (verbose) {
    cat (paste0(signif(training$gc * 100, digits = 4), "% GC\n"))
    flush.console()
  }



  # Build the NODE structure incrementally as an R data frame

  Nodes.df <- data.frame(index=integer(), type=character(), strand=character(), stop_val=integer(), edge=logical(), stringsAsFactors=FALSE)

  # Find the potential STARTs and STOPs in the forward frames

  for (frame in c(1,2,0)) {   # Order equivalent to (1,2,3) modulo 3
                              # Order in which the frames are examined is not important

    Coords.df <- data.frame(locate=integer(), pattrn=character(), stringsAsFactors=FALSE)

    for (NNN in c("ATG","GTG","TTG")) {
      vector <- matchPattern(NNN, sequence)
      if (length(vector) > 0) {
        coords <- start(vector)
        locate <- coords[(coords %% 3) == frame]
        pattrn <- rep(NNN, length(locate))
        Coords.df <- rbind(Coords.df, data.frame(locate, pattrn, stringsAsFactors=FALSE))
      }
    }

    for (NNN in c("TAG","TGA","TAA")) {
      vector <- matchPattern(NNN, sequence)
      if (length(vector) > 0) {
        coords <- start(vector)
        locate <- coords[(coords %% 3) == frame]
        pattrn <- rep("STOP", length(locate))
        Coords.df <- rbind(Coords.df, data.frame(locate, pattrn, stringsAsFactors=FALSE))
      }
    }

    # Add dummy STOPS and STARTS for potential edge nodes

    pattrn <- c("STOP","ATG","STOP")
    if (frame == 1) { locate <- c(-5,1,seq_len-(seq_len%%3-frame)%%3) }
    if (frame == 2) { locate <- c(-4,2,seq_len-(seq_len%%3-frame)%%3) }
    if (frame == 0) { locate <- c(-3,3,seq_len-(seq_len%%3-frame)%%3) }

    # Final STOP goes into last complete codon in the appropriate frame
    if (frame == 1) { locate <- c(-5,1,seq_len-2-((seq_len-2)%%3-frame)%%3) }
    if (frame == 2) { locate <- c(-4,2,seq_len-2-((seq_len-2)%%3-frame)%%3) }
    if (frame == 0) { locate <- c(-3,3,seq_len-2-((seq_len-2)%%3-frame)%%3) }

    Coords.df <- rbind(data.frame(locate, pattrn, stringsAsFactors=FALSE), Coords.df)

    # Sort the lists by location
    Coords.df <- Coords.df[order(Coords.df$locate),]

    coord_node.df <- coord2node(Coords.df, seq_len, 1) # 1 indicates forward strand
    if (nrow(coord_node.df) > 0) {
      Nodes.df <- rbind(Nodes.df, coord_node.df)
    }
  }


  # Find the potential STARTs and STOPs in the reverse frames

  for (frame in c(1,2,0)) {   # Order equivalent to (1,2,3) modulo 3
                              # Order in which the frames are examined is not important

    Coords.df <- data.frame(locate=integer(), pattrn=character(), stringsAsFactors=FALSE)

    for (NNN in c("ATG","GTG","TTG")) {
      vector <- matchPattern(NNN, reverse)
      coords <- start(vector)
      locate <- coords[(coords %% 3) == frame]
      pattrn <- rep(NNN, length(locate))
      Coords.df <- rbind(Coords.df, data.frame(locate, pattrn, stringsAsFactors=FALSE))
    }

    for (NNN in c("TAG","TGA","TAA")) {
      vector <- matchPattern(NNN, reverse)
      coords <- start(vector)
      locate <- coords[(coords %% 3) == frame]
      pattrn <- rep("STOP", length(locate))
      Coords.df <- rbind(Coords.df, data.frame(locate, pattrn, stringsAsFactors=FALSE))
    }

    # Add dummy STOPS and STARTS for potential edge nodes

    pattrn <- c("STOP","ATG","STOP")
    if (frame == 1) { locate <- c(-5,1,seq_len-(seq_len%%3-frame)%%3) }
    if (frame == 2) { locate <- c(-4,2,seq_len-(seq_len%%3-frame)%%3) }
    if (frame == 0) { locate <- c(-3,3,seq_len-(seq_len%%3-frame)%%3) }

    # Final STOP goes into last complete codon in the appropriate frame
    if (frame == 1) { locate <- c(-5,1,seq_len-2-((seq_len-2)%%3-frame)%%3) }
    if (frame == 2) { locate <- c(-4,2,seq_len-2-((seq_len-2)%%3-frame)%%3) }
    if (frame == 0) { locate <- c(-3,3,seq_len-2-((seq_len-2)%%3-frame)%%3) }

    Coords.df <- rbind(data.frame(locate, pattrn, stringsAsFactors=FALSE), Coords.df)

    # Sort the lists by location
    Coords.df <- Coords.df[order(Coords.df$locate),]

    coord_node.df <- coord2node(Coords.df, seq_len, -1) # 1 indicates reverse strand
    if (nrow(coord_node.df) > 0) {
      Nodes.df <- rbind(Nodes.df, coord_node.df)
    }
    remove(Coords.df)
    remove(coord_node.df)
  }

# remove(Coords.df)
# remove(coord_node.df)


  # Sort the nodes:

  if (nrow(Nodes.df) > 0) {
    Nodes.df <- Nodes.df[order(Nodes.df$ndx, -rank(Nodes.df$strand)),]
    Nodes.df <- Nodes.df[!duplicated(Nodes.df),]
  }

  # Uncomment to return Node dataframe for debugging
  # return(Nodes.df)

  # Point A - see comments at the beginning of this file.

  # We now know the total number of nodes so add all remaining columns to the nodes dataframe

  Nodes.df$star_ptr_1     <- 0     # Array of starts within MAX_SAM_OVLP bases of a stop in three frames
  Nodes.df$star_ptr_2     <- 0 
  Nodes.df$star_ptr_3     <- 0 
  Nodes.df$gc_bias        <- 0     # Frame of highest GC content within this node
  Nodes.df$gc_score_1     <- 0.0   # Array of %GC content in different codon positions
  Nodes.df$gc_score_2     <- 0.0 
  Nodes.df$gc_score_3     <- 0.0 
  Nodes.df$cscore         <- 0.0   # Coding score for this node (based on 6-mer usage)
  Nodes.df$gc_cont        <- 0.0   # GC content for this node
  Nodes.df$rbs_1          <- 0     # Shine-Dalgarno RBS score for this node ... best motif with exact match
  Nodes.df$rbs_2          <- 0     #                                        ... best motif with mismatchs
  Nodes.df$motif_ndx      <- 0     # Index of the best motif for this node
  Nodes.df$motif_len      <- 0     # Length of the motif
  Nodes.df$motif_spacer   <- 0     # Spacer between coding start and the motif
  Nodes.df$motif_spacendx <- 0     # Index for this spacer length
  Nodes.df$motif_score    <- 0.0   # Score for the motif
  Nodes.df$uscore         <- 0.0   # Score for the upstream -1/-2, -15 to -45 region
  Nodes.df$tscore         <- 0.0   # Score for the ATG/GTG/TTG value
  Nodes.df$rscore         <- 0.0   # Score for the RBS motif
  Nodes.df$sscore         <- 0.0   # Score for the strength of the start codon
  Nodes.df$traceb         <- -1    # Traceback to connecting node
  Nodes.df$tracef         <- -1    # Trace to forward node
  Nodes.df$ov_mark        <- -1    # Marker to help untangle overlapping genes
  Nodes.df$score          <- 0.0   # Score of total solution to this point
  Nodes.df$elim           <- FALSE # If TRUE, eliminate this gene from the model


  # Scan all the ORFS looking for a potential GC bias in a particular codon position.
  # This information will be used to acquire a good initial set of genes.

  if (DEBUG) { cat("starting calc_most_gc_frame-1\n") }
  gc_frame <- calc_most_gc_frame(sequence)
  if (DEBUG) { cat("finishing calc_most_gc_frame-1\n") }

  # At this point, we expect all further modifications to the nodes to be made in a C/C++ environment,
  #   so we shift the node values that are node indices from a 1-based to a 0-based coordinate system.

  Nodes.df$ndx      <- Nodes.df$ndx      - 1
  Nodes.df$stop_val <- Nodes.df$stop_val - 1

  # Note: The Prodigal C function record_gc_bias has been split
  #   to update the NODE structure and the TRAINING structure separately

  Nodes.df <- as.data.frame(record_gc_bias_node(gc_frame, Nodes.df))
  training$bias <- as.vector(record_gc_bias_training(Nodes.df, training))

  if (verbose) {
    cat ("Looking for GC bias in different frames ... frame bias scores:",
      signif(training$bias[1], digits = 3),
      signif(training$bias[2], digits = 3),
      signif(training$bias[3], digits = 3),
      "\n"
    )
    flush.console()
  }


  # Do an initial dynamic programming routine with just the GC frame bias used as a scoring function.
  # This will get an initial set of genes to train on.

  # Note: This function has been moved to the do_training routine
  # Nodes.df <- as.data.frame(record_overlapping_starts(Nodes.df, training, 0))

  if (DEBUG) { cat("starting training\n") }
  training <- as.list(do_training(Nodes.df, training, as.character(sequence), as.character(reverse), verbose))
  if (DEBUG) { cat("finishing training\n") }

  # Redimension the mot_wt member -- which started life as a 3-D array but was unpacked into a 1-D array
  # as it passed through an Rcpp data type

  dim(training$mot_wt) <- c(4,4,4096)

  # Uncomment to return training structure for debugging
  # return(training)

  # Precaution: Save the training structure to be used for each sequence

  training_global <- training



  #---------------------------
  # LOOP over set of sequences
  #---------------------------

  ## Note: There's a lot of repeated code here. Could be made more compact, but probably not more efficient.

  if (verbose) {
    cat ("Request: Single Genome, Phase: Gene Finding\n")
    flush.console()
  }

  allGenes.df <- data.frame()
  offset <- 0

  for (seqNum in 1:numSeq) {

    training <- training_global

    sequence <- Sequences[[seqNum]]
    reverse <- reverseComplement(sequence)

    seq_len = length(sequence)

    if (verbose) {
      cat (paste0("Finding genes in sequence # ", seqNum, " (", seq_len, " bp) ... \n"))
      flush.console()
    }

    # Build the NODE structure incrementally as an R data frame

    Nodes.df <- data.frame(index=integer(), type=character(), strand=character(), stop_val=integer(), edge=logical(), stringsAsFactors=FALSE)

    # Find the potential STARTs and STOPs in the forward frames

    for (frame in c(1,2,0)) {   # Order equivalent to (1,2,3) modulo 3 
                                # Order in which the frames are examined is not important

      Coords.df <- data.frame(locate=integer(), pattrn=character(), stringsAsFactors=FALSE)

      for (NNN in c("ATG","GTG","TTG")) {
        vector <- matchPattern(NNN, sequence)
        coords <- start(vector)
        locate <- coords[(coords %% 3) == frame]
        pattrn <- rep(NNN, length(locate))
        Coords.df <- rbind(Coords.df, data.frame(locate, pattrn, stringsAsFactors=FALSE))
      }

      for (NNN in c("TAG","TGA","TAA")) {
        vector <- matchPattern(NNN, sequence)
        coords <- start(vector)
        locate <- coords[(coords %% 3) == frame]
        pattrn <- rep("STOP", length(locate))
        Coords.df <- rbind(Coords.df, data.frame(locate, pattrn, stringsAsFactors=FALSE))
      }

      # Add dummy STOPS and STARTS for potential edge nodes

      pattrn <- c("STOP","ATG","STOP")
      if (frame == 1) { locate <- c(-5,1,seq_len-(seq_len%%3-frame)%%3) }
      if (frame == 2) { locate <- c(-4,2,seq_len-(seq_len%%3-frame)%%3) }
      if (frame == 0) { locate <- c(-3,3,seq_len-(seq_len%%3-frame)%%3) }

      # Final STOP goes into last complete codon in the appropriate frame
      if (frame == 1) { locate <- c(-5,1,seq_len-2-((seq_len-2)%%3-frame)%%3) }
      if (frame == 2) { locate <- c(-4,2,seq_len-2-((seq_len-2)%%3-frame)%%3) }
      if (frame == 0) { locate <- c(-3,3,seq_len-2-((seq_len-2)%%3-frame)%%3) }

      Coords.df <- rbind(data.frame(locate, pattrn, stringsAsFactors=FALSE), Coords.df)

      if (DEBUG) { cat(paste("   Number of coordinates in Coords.df:", nrow(Coords.df), "\n")) }

      if (nrow(Coords.df) > 0) {
        # Sort the lists by location
        Coords.df <- Coords.df[order(Coords.df$locate),]

        Nodes.df <- rbind(Nodes.df, coord2node(Coords.df, seq_len, 1))    # 1 indicates forward strand
      }
    }


    # Find the potential STARTs and STOPs in the reverse frames

    for (frame in c(1,2,0)) {   # Order equivalent to (1,2,3) modulo 3 
                                # Order in which the frames are examined is not important

      Coords.df <- data.frame(locate=integer(), pattrn=character(), stringsAsFactors=FALSE)

      for (NNN in c("ATG","GTG","TTG")) {
        vector <- matchPattern(NNN, reverse)
        coords <- start(vector)
        locate <- coords[(coords %% 3) == frame]
        pattrn <- rep(NNN, length(locate))
        Coords.df <- rbind(Coords.df, data.frame(locate, pattrn, stringsAsFactors=FALSE))
      }

      for (NNN in c("TAG","TGA","TAA")) {
        vector <- matchPattern(NNN, reverse)
        coords <- start(vector)
        locate <- coords[(coords %% 3) == frame]
        pattrn <- rep("STOP", length(locate))
        Coords.df <- rbind(Coords.df, data.frame(locate, pattrn, stringsAsFactors=FALSE))
      }

      # Add dummy STOPS and STARTS for potential edge nodes

      pattrn <- c("STOP","ATG","STOP")
      if (frame == 1) { locate <- c(-5,1,seq_len-(seq_len%%3-frame)%%3) }
      if (frame == 2) { locate <- c(-4,2,seq_len-(seq_len%%3-frame)%%3) }
      if (frame == 0) { locate <- c(-3,3,seq_len-(seq_len%%3-frame)%%3) }

      # Final STOP goes into last complete codon in the appropriate frame
      if (frame == 1) { locate <- c(-5,1,seq_len-2-((seq_len-2)%%3-frame)%%3) }
      if (frame == 2) { locate <- c(-4,2,seq_len-2-((seq_len-2)%%3-frame)%%3) }
      if (frame == 0) { locate <- c(-3,3,seq_len-2-((seq_len-2)%%3-frame)%%3) }

      Coords.df <- rbind(data.frame(locate, pattrn, stringsAsFactors=FALSE), Coords.df)

      if (DEBUG) { cat(paste("   Number of coordinates in Coords.df:", nrow(Coords.df), "\n")) }

      if (nrow(Coords.df) > 0) {
        # Sort the lists by location
        Coords.df <- Coords.df[order(Coords.df$locate),]

        Nodes.df <- rbind(Nodes.df, coord2node(Coords.df, seq_len, -1))    # -1 indicates reverse strand
      }
    }

    if (DEBUG) { cat(paste("   Number of rows in Nodes.df:", nrow(Nodes.df), "\n")) }

    if (nrow(Nodes.df) > 0) {

      # Sort the nodes:

      Nodes.df <- Nodes.df[order(Nodes.df$ndx, -rank(Nodes.df$strand)),]

      # Point A - see comments at the beginning of this file.

      # We now know the total number of nodes so add all remaining columns to the nodes dataframe

      Nodes.df$star_ptr_1     <- 0     # Array of starts within MAX_SAM_OVLP bases of a stop in three frames
      Nodes.df$star_ptr_2     <- 0 
      Nodes.df$star_ptr_3     <- 0 
      Nodes.df$gc_bias        <- 0     # Frame of highest GC content within this node
      Nodes.df$gc_score_1     <- 0.0   # Array of %GC content in different codon positions
      Nodes.df$gc_score_2     <- 0.0 
      Nodes.df$gc_score_3     <- 0.0 
      Nodes.df$cscore         <- 0.0   # Coding score for this node (based on 6-mer usage)
      Nodes.df$gc_cont        <- 0.0   # GC content for this node
      Nodes.df$rbs_1          <- 0     # Shine-Dalgarno RBS score for this node ... best motif with exact match
      Nodes.df$rbs_2          <- 0     #                                        ... best motif with mismatchs
      Nodes.df$motif_ndx      <- 0     # Index of the best motif for this node
      Nodes.df$motif_len      <- 0     # Length of the motif
      Nodes.df$motif_spacer   <- 0     # Spacer between coding start and the motif
      Nodes.df$motif_spacendx <- 0     # Index for this spacer length
      Nodes.df$motif_score    <- 0.0   # Score for the motif
      Nodes.df$uscore         <- 0.0   # Score for the upstream -1/-2, -15 to -45 region
      Nodes.df$tscore         <- 0.0   # Score for the ATG/GTG/TTG value
      Nodes.df$rscore         <- 0.0   # Score for the RBS motif
      Nodes.df$sscore         <- 0.0   # Score for the strength of the start codon
      Nodes.df$traceb         <- -1    # Traceback to connecting node
      Nodes.df$tracef         <- -1    # Trace to forward node
      Nodes.df$ov_mark        <- -1    # Marker to help untangle overlapping genes
      Nodes.df$score          <- 0.0   # Score of total solution to this point
      Nodes.df$elim           <- FALSE # If TRUE, eliminate this gene from the model


      # Scan all the ORFS looking for a potential GC bias in a particular codon position.
      # This information will be used to acquire a good initial set of genes.

      if (DEBUG) { cat("starting calc_most_gc_frame-2\n") }
      gc_frame <- calc_most_gc_frame(sequence)
      if (DEBUG) { cat("finishing calc_most_gc_frame-2\n") }

      # At this point, we expect all further modifications to the nodes to be made in a C/C++ environment,
      #   so we shift the node values that are node indices from a 1-based to a 0-based coordinate system.

      Nodes.df$ndx      <- Nodes.df$ndx      - 1
      Nodes.df$stop_val <- Nodes.df$stop_val - 1

      # Note: The Prodigal C function record_gc_bias has been split
      #   to update the NODE structure and the TRAINING structure separately
      # We do NOT update the TRAINING structure here

      if (DEBUG) { cat("starting record_gc_bias_node\n") }
      Nodes.df <- as.data.frame(record_gc_bias_node(gc_frame, Nodes.df))
      if (DEBUG) { cat("finishing record_gc_bias_node\n") }

      # This will get an initial set of genes to train on.

      # Note: The call to 'record_overlapping_starts' is now inside the Rcpp function 'find_overlaps'
      # Nodes.df <- as.data.frame(record_overlapping_starts_training(Nodes.df, training, 0))

      if (DEBUG) { cat("starting find_overlaps\n") }
      Nodes.df <- as.data.frame(find_overlaps(Nodes.df, training, 0))
      if (DEBUG) { cat("finishing find_overlaps\n") }

      # Find the genes for this sequence

      if (DEBUG) { cat(paste("   Number of nodes passed to 'find_genes'", nrow(Nodes.df), "\n")) }
      Genes.df <- as.data.frame(find_genes(Nodes.df, training, as.character(sequence), as.character(reverse)))
      if (DEBUG) { cat(paste("     Return from 'find_genes'\n")) }

      remove(Nodes.df)

      if (verbose) {
        cat (paste0(" done!  ", nrow(Genes.df), " genes predicted\n"))
        flush.console()
      }

      if (DEBUG) { cat(paste("   Number of genes in Genes.df:", nrow(Genes.df), "\n")) }

      if (nrow(Genes.df) > 0) {

        # Rename the genes ...
        if (seqNum > 0) {
          for (i in 1:nrow(Genes.df)) {
            Genes.df$identifier[i] <- as.character(paste0(seqNum, "_", i + offset))
          }
        }

        # Show only 5 significant figures for GC content

        Genes.df$gc_cont <- round(as.numeric(Genes.df$gc_cont),5)

        allGenes.df <- rbind(allGenes.df, Genes.df, stringsAsFactors=FALSE)

        offset <- offset + nrow(Genes.df)

        remove(Genes.df)
      }
    }
  }

  return(allGenes.df)
}
