#' runLinclust function modified for annotation pipeline
#'
runLinclust_DF <- function(Sequences.df) {
  # Arguments: 
  # Sequences.df: dataframe with 3 columns, the accession, identifier and protein sequence.

  ## TEMP COUNTER ###
  gappedAlignmentCount <- 0

  ## Global variables

  # Check whether RBiotools has been initialized, that is, do the global variables exist?

  incr <- 32  # increment for interleaving, value from the C++ Linclust implementation

  # Rename columns
  colnames(Sequences.df) <- c("accession", "identifier", "protein")
  # Interleave the protein sequences, consistent with C++ implementation of Linclust
  # --------------------------------------------------------------------------------

  last <- nrow(Sequences.df)
  newOrder.df <- data.frame(accession = character(), identifier = character(), protein = character(), stringsAsFactors = FALSE)
  n <- 1
  beg <- 0
  for (i in 1:incr) {
    beg <- beg + 1
    j <- beg
    while (j <= last) {
      newOrder.df <- rbind(newOrder.df, Sequences.df[j, ])
      n <- n + 1
      j <- j + incr
    }
  }

  # Remove '*' from the end of protein sequences --------------------------------------------

  for (i in 1:last) {
    newOrder.df[i, ]$protein <- str_remove(newOrder.df[i, ]$protein, "\\*$")
  }



  # Call the Rcpp function computeLinclustDatasets to create the datasets, in order, * pref (later reused by Linclust as 'pref_filter1') *
  # pref_rescore1 * pre_clust * order_redundancy * pref_filter2 * pref_rescore2 and return pre_clust ...  ... and pref_rescore2, if SLOW mode


  dataset_vectors <- as.list(computeLinclustDatasets(newOrder.df, 10, 0))

  # extract pre_clust -----------------

  seqId <- dataset_vectors[["preClust_seqId"]]
  repseq <- dataset_vectors[["preClust_repseq"]]

  # Adjust seqId for 1-based indexing .... v
  pre_clust.df <- data.frame(seqId = seqId + 1, repseq = repseq, stringsAsFactors = FALSE)
  pre_clust.df$seqId <- as.integer(pre_clust.df$seqId)
  pre_clust.df$repseq <- as.logical(pre_clust.df$repseq)

  # Add group number to pre_clust.df --------------------------------

  groupNum <- c()
  gNum <- 0

  for (i in 1:nrow(pre_clust.df)) {
    if (pre_clust.df[i, ]$repseq == TRUE) {
      gNum <- gNum + 1
    }
    groupNum <- c(groupNum, gNum)
  }

  pre_clust.df <- cbind(pre_clust.df, groupNum)

  # Add additional information to the newOrder dataframe ...  -------------------------------------------------------- 1) seqId from the Rcpp
  # function are 0-indexed switch to 1-indexed ....v
  newOrder.df <- cbind(seq.int(1, nrow(newOrder.df), 1), newOrder.df)

  # 2) protein length (# of AAs)
  newOrder.df <- cbind(newOrder.df, nchar(newOrder.df$protein))

  # Rename columns
  colnames(newOrder.df) <- c("seqId", "accession", "identifier", "protein", "length")

  final <- merge(newOrder.df, pre_clust.df)
  final <- final[c("seqId", "identifier", "protein", "length", "repseq", "groupNum")]
  return(final)
  # accession can be ignored, identifier is from the original fasta file, seq_id is also unncessary because the order has been preserved.
}
