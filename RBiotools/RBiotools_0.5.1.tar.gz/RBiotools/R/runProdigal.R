#' runProdigal
#'
#' A convenience function that calls the \code{prodigal} gene calling function for a set of genomes and adds the results to the \code{RBiotools} global data store
#'
#' @param accessionList character vector containing GenBank accession numbers
#' @param verbose       logical, indicating whether to report algorithm progress consistent with the original C implementation
#'
#' @details This convenience function calls the \code{prodigal} gene calling function for a set of genomes specified by accession numbers. For each genome in the set, \code{runProdigal} adds the called genes to \code{ProdigalCalls}, an \code{RBiotools} global data frame containing called genes, genomic coordinates, scores, and nucleotide and protein product sequences. The function \code{fetchProdigalCalls} can then be used to extract a data frame from \code{ProdigalCalls} with gene calls for a specified genome.
#'
#' \emph{\strong{Note:} \code{runProdigal} will seldom, if ever, need to be called directly by the \code{RBiotools} user. \code{RBiotools} functions will automatically initiate calling of protein genes, if required for use by another function.}
#'
#' @return None
#'
#' @examples
#' \dontrun{
#' myGenomes <- c("CP003284",
#'                "CP003597",
#'                "NONSENSE", # skipped, no corresponding genomic sequence
#'                "CP003289",
#'                "CP006632"
#'               )
#' runProdigal(myGenomes)
#' calledGenes <- fetchProdigalCalls("CP003284")
#' }
#'
#' @useDynLib RBiotools
#' @exportPattern "^[[:alpha:]]+"



runProdigal <- function(accessionList, verbose = TRUE) {

  # Check whether RBiotools has been initialized,
  #   that is, do the global variables exist?

  if (!exists("GenomeSeqList")) {   # NOT initialized
    initializeRBiotools()
  }

  ## Global variables

  get("GenomeSeqList", envir = .GlobalEnv)
  get("orgName.df", envir = .GlobalEnv)
  get("orgData.df", envir = .GlobalEnv)
  get("ProdigalCalls", envir = .GlobalEnv)
  get("RNAmmerCalls", envir = .GlobalEnv)

  for (uncheckedID in accessionList) {

    organism <- checkIdentifier(uncheckedID)

    calls <- nrow(ProdigalCalls[which(ProdigalCalls$accession == organism),])

    if (calls > 0) {
      if (verbose) {
        cat(paste0(calls, " genes called for genome with accession ID:", organism, ". Skipping ...\n"))
      }
    }

    else {

      # Check whether the the genome has been downloaded from GenBank

      seqSet <- GenomeSeqList[organism][[organism]]

      if (is.null(seqSet)) {
        downloadGenBank(organism)  # downloadGenBank prints message with GenBank ID
      }


      # Extract set of genome sequences from the Genome Sequence List identified by the accession ID
      seqSet <- GenomeSeqList[organism][[organism]]

      # Call Prodigal

      if (verbose) {
        cat("----------\n")
        cat(paste("Predicting protein genes for genome with accession ID:", organism, "\n"))
      }

      genes.df <- prodigal(seqSet, verbose = verbose)
  
      # The R prodigal function returns everything that the C prodigal function returns,
      #   including a lot of score values of little interest to the casual user, therefore ...
      # Keep only a subset of the data frame columns returned by Prodigal

      keeps <- c("identifier", "begin", "end", "strand", "partial", "start_type", "rbs_motif", "rbs_spacer", "gc_cont", "confidence", "gene", "protein")
      genes.df <- genes.df[keeps]

      # Add the accession number of this organism as the first column of the data frame
      genes.df <- cbind(accession = organism, genes.df)

      # Add calls to the global Prodigal data frame
      # NOTE: Prodigal calls are NOT bound to the global Prodigal data frame
      #       until genes from ALL organisms in the accession list have been called.
      ProdigalCalls <<- rbind(ProdigalCalls, genes.df)

    }
  }
}
